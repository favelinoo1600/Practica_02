#ifndef GATO_H
#define GATO_H

class Gato
{
public:
	Gato(int edadInicial, int pesoInicial);
	~Gato();
	int ObtenerPeso() const;
	void AsignarPeso(int peso);
	int ObtenerEdad() const;
	void AsignarEdad(int edad);
	void Maullar();
private:
	float suPeso;
	int suEdad;
};

#endif
