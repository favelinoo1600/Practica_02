#include <iostream>
#include "Gato.h"

using namespace std;

Gato::Gato(int edadInicial, int pesoInicial){
	suEdad = edadInicial;
	suPeso = pesoInicial;
	cout << "Se ha creado un objeto Gato de edad " << edadInicial <<" y pesa " << pesoInicial << " kilogramos." << endl;
}

Gato::~Gato(){
	cout << "El objeto Gato se destruira en 3, 2, 1 .... ya fue...." << endl;
}

int Gato::ObtenerPeso() const{
	return suPeso;
}

void Gato::AsignarPeso(int peso){
	suPeso = peso;
}

int Gato::ObtenerEdad()const{
	return suEdad;
}

void Gato::AsignarEdad(int edad){
	suEdad = edad;
}

void Gato::Maullar(){
	cout << "Miau" << endl;
}
