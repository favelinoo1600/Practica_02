#include <iostream>
#include "Gato.h"

using namespace std;

Gato::Gato(int edadInicial){
	suEdad = edadInicial;
	cout << "Se ha creado un objeto Gato de edad " << edadInicial << endl;
}

Gato::~Gato(){
	cout << "El objeto Gato se destruira en 3, 2, 1 .... ya fue...." << endl;
}

int Gato::ObtenerEdad(){
	return suEdad;
}

void Gato::AsignarEdad(int edad){
	suEdad = edad;
}

void Gato::Maullar(){
	cout << "Miau" << endl;
}
